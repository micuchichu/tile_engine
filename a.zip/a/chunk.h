#pragma once

#include "tile.h"
#include "headers.h"
#include "utils.h"

class Chunk
{
public:
	Chunk() = default;

	std::vector<Tile> getChunk();

	void updateChunk(std::vector<Tile> newChunk);

	void push_back(Tile tile);

	size_t size();

	void clear();

	bool empty();

	void erase(std::vector<Tile>::const_iterator _Where);

	std::vector<Tile>::iterator begin();

private:
	std::vector<Tile> chunk;
};