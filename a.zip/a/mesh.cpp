#include "mesh.h"

Tile MeshObj::tile()
{
	return _tile;
}

int MeshObj::worldIndex()
{
	return world_index;
}

int MeshObj::chunk()
{
	return _chunk;
}