#include "world.h"

void LoadChunk(std::map<int, Chunk>& chunks, int chunk)
{
    if(chunks.find(chunk) != chunks.end())
        if (!chunks[chunk].empty())
        {
            return;
        }

    Tile tile(0, { 0, 0 });

    for (int i = 16 * chunk; i < 16 + 16 * chunk; i++)
    {
        float y = float((int)(generateNoise(i, 0) * 2048 / 64));

        for (int j = y + 1; j < 32; j++)
        {
            if (generateNoise(i, j) < 0.2f) {
                if (j < y + 4)
                    tile = { 5, Vector2{ i * 64.0f, j * 64.0f } };
                else
                    tile = { 1, Vector2{ i * 64.0f, j * 64.0f } };

                chunks[chunk].push_back(tile);
            }
        }

        tile = { 3, Vector2{ i * 64.0f, y * 64.0f } };
        chunks[chunk].push_back(tile);
    }
}

void UnloadChunk(std::map<int, Chunk>& tiles, int chunk)
{
	
}
