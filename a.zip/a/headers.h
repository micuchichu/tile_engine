#pragma once

#include <fstream>
#include <iostream>
#include <vector>
#include <functional>
#include <algorithm>
#include <cmath>
#include "raylib.h"
#include <filesystem>
#include <map>
#include <sstream>
//#include "../../../../Downloads/raylib-master/raylib-master/src/raylib.h"
