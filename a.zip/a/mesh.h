#pragma once

#include "tile.h"

class MeshObj
{
public:
	MeshObj() = default;

	MeshObj(Tile tile, int index, int chunk)
		: _tile(tile), world_index(index), _chunk(chunk) {};

	Tile tile();

	int worldIndex();

	int chunk();

private:
	Tile _tile;
	int world_index;
	int _chunk;
};